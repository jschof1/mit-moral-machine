module.exports = {
  server: ['connect:server'],
  spoor: ['connect:spoorOffline']
};
