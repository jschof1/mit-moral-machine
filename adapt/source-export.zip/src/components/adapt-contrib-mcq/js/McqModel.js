import ItemsQuestionModel from 'core/js/models/itemsQuestionModel';

export default class McqModel extends ItemsQuestionModel {}
